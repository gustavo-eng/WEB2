Na pasta descompactada rodar o código:
npm install
